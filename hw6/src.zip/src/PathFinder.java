public class PathFinder {
  private final GridWorld gridWorld;
    
  public PathFinder(GridWorld gridWorld) {
    this.gridWorld = gridWorld;
  }

  // Return a list of moves to get from the starting point of the grid to the ending
  public SinglyLinkedList<Move> findShortestPath() {
    // Implement this!
    return null;
  }
}
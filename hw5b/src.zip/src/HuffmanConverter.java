import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class HuffmanConverter {
  // Usage from the command line:
  // cat just_to_say.txt | java HuffmanConverter encode just_to_say_spec.txt
  public static void main(String [] args) throws IOException {
    String mode = args[0].toLowerCase();
    String treeFile = args[1];

    String treeStr = readfile(treeFile);
    
    // TODO - copy HuffmanTree.java from part A, and implement loadTree()
    // HuffmanTree tree = HuffmanTree.loadTree(treeStr);

    String input = readStdin();

    if (mode.equals("decode")) {

      // TODO - implement this!
      System.out.println("decode mode not implemented");
    } else if (mode.equals("analyze")) {

      // TODO - implement this!
      System.out.println("analyze mode not implemented");

    } else if (mode.equals("encode")) {
      // TODO - implement this!
      System.out.println("encode mode not implemented");
    } else {
      System.out.println("Unknown Mode: " + mode);
    }
  }

  public static String readfile(String fileName) throws IOException {
    StringBuilder result = new StringBuilder();
    BufferedReader reader = new BufferedReader(new FileReader(fileName));
    int c;
    while ((c = reader.read()) != -1) {
        result.append((char)c);
    }
    reader.close();
    return result.toString();
  }

  public static String readStdin() throws IOException {
    StringBuilder result = new StringBuilder();
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    int c;
    while ((c = reader.read()) != -1) {
        result.append((char)c);
    }
    reader.close();
    return result.toString();
  }
}
